# Inhalte im geschlossenen Kreis pflegen

Es liegen keine bestätigten konkreten Projekte oder Termine vor. Die Projektseite beschreibt die gemeinsame Arbeitsweise, ohne Projekte, Erfolge, Partner oder Nutzerzahlen zu erfinden. Zusammenkünfte werden allgemein als interne Abstimmung erwähnt. Kein neues Kalender- oder Registrierungssystem.

Bestätigte Projekte werden in `src/data/projects.js` gepflegt. `publishedProjects` ist historisch benannt; die Ausgabe erfolgt im geschützten Bereich. Jeder Eintrag benötigt `confirmed: true` sowie `name`, `description`, `problem`, `approach`, `status`, `collaboration`. Ein echter HTTPS-Ergebnislink in `url` ist freiwillig. Ohne bestätigte Angaben bleibt die Liste leer. Keine Platzhalter veröffentlichen.

Inhalte nur dann eintragen, wenn sie für den zugangsberechtigten Kreis bestimmt und sachlich bestätigt sind. Ein öffentliches GitHub-Repository macht trotzdem die Quellen einsehbar: vor internen Projektangaben Repository-Zugriff klären. Vertrauliche Notizen, persönliche Kontaktdaten und Finanzen bleiben außerhalb des Projekts. Die Website braucht sie nicht.

Nach Änderungen `npm run build`, passende Tests und `npm run package` ausführen. Die [Netlify-Anleitung](HOSTING.md) gilt auch für Updates: vollständiges Deployment mit beiden Edge Functions. Keine Einzeldateien über einen statischen Upload veröffentlichen. Frühere Deployments behalten alte Inhalte und ihre damaligen Zugriffseinstellungen; nötigenfalls separat entfernen.

Name und E-Mail werden in `src/data/site.js` gepflegt. Rechtliche Angaben stehen in `src/data/legal.js`, Rechtstexte in `scripts/pages.mjs`. `imprintNames` und `responsibleNames` sind bewusst getrennt: Finn wurde nur aus dem Impressum entfernt, bleibt aber nach ausdrücklicher Angabe gemeinsam verantwortlich. `emailContact` ist Paul Zwicke, `completedRequestRetentionMonths` beträgt 3. Eine später ausdrücklich zur Veröffentlichung genannte Anschrift gehört zeilenweise in `addressLines`; bis dahin bleibt diese Liste leer und der konkrete Hinweis auf die fehlende Anschrift sichtbar. Keine Adresse erfinden oder ungefragt aus alten Ständen wiederherstellen. Alle Seiten bleiben `noindex`; das ist ergänzend zum serverseitigen Zugangsschutz, kein Ersatz dafür.

Passwort und Sitzungsschlüssel ausschließlich in Netlify setzen, danach neu deployen. Die Zugangskontrolle, Hostliste, `onError: fail`, Rate-Limit und `no-store`-Header bei Pflege nicht entfernen. Keine Browser-Passwortprüfung als Ersatz einbauen.

Für abgeschlossene Vorstellungsanfragen setzt Paul Zwicke die Dreimonatsfrist im Gmail-Postfach und in vorhandenen Bearbeitungskopien um. Maßgeblich ist der Abschluss der Bearbeitung, nicht einfach das Eingangsdatum. Angaben für laufende Zusammenarbeit oder gesetzliche Aufbewahrung bleiben nur für den jeweiligen Zweck erhalten. Die Website führt diese Löschung nicht automatisch aus und sendet keine Nachrichten.
